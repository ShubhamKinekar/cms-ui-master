export const environment = {
    production: false,
    environment: 'DEV',
    apiUrl: 'http://10.0.82.70:7700/',
    pdfFilePath : 'http://10.0.82.70:8081/'
  
  };
  