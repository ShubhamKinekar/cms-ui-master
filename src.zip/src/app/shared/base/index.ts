export * from './base-service/base-data.service';
export * from './base-details/base-details.component';
export * from './base-list/base-list.component';
