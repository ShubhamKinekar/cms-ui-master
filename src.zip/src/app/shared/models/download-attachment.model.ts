export class DownloadAttachmentModel {
  id?: number;
  savePath?: string;
  name?: string;
}
