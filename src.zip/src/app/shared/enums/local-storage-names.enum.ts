export enum LocalStorageNames {
  CurrentUser = 'CurrentUser',
}

