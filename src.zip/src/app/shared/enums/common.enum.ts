export enum Condition {
  And = 'And',
  Or = 'Or'
}
