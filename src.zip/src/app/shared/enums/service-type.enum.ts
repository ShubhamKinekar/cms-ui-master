export enum ServiceType {
  None = 'None',
  Scrutiny='scrutiny',
  Checker = 'checker',
  DataEntry = 'dataEntry',
}