import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-nsdl-account-detail',
  templateUrl: './master-nsdl-account-detail.component.html',
  styleUrls: ['./master-nsdl-account-detail.component.css']
})
export class MasterNsdlAccountDetailComponent implements OnInit {
  constructor() { }


  ngOnInit(): void {
  }

}
